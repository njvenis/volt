"""The published OpenAPI document covers each supported auth-mode route set."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "volt_export_openapi", ROOT / "tools" / "export_openapi.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class OpenAPIModeExportTests(unittest.TestCase):
    def test_combined_schema_includes_local_oidc_and_base_commands(self):
        schema = MODULE.export_schema()
        paths = schema["paths"]
        self.assertIn("/api/v1/auth/setup/claim", paths)
        self.assertIn("/api/v1/auth/local/login", paths)
        self.assertIn("/api/v1/auth/session", paths)
        self.assertIn("/api/v1/auth/login", paths)
        self.assertIn("/api/v1/assessment/commands", paths)
        self.assertIn("/api/v1/assessment/commands/{command_id}/abandon", paths)
        self.assertIn("/api/v1/deployment", paths)
        claim = paths["/api/v1/auth/setup/claim"]["post"]
        body_schema = claim["requestBody"]["content"]["application/json"]["schema"]
        self.assertEqual(set(body_schema["properties"]),
            {"capability", "username", "display_name", "password"})
        session_schema = paths["/api/v1/auth/session"]["get"]["responses"]["200"][
            "content"]["application/json"]["schema"]
        self.assertEqual(paths["/api/v1/auth/session"]["get"]["x-uvm-auth-modes"],
            ["local", "oidc"])
        self.assertEqual(len(session_schema["oneOf"]), 2)
        local_response = next(item for item in session_schema["oneOf"]
            if "local" in item["x-uvm-auth-modes"])
        local_model = schema["components"]["schemas"][local_response["$ref"].rsplit("/", 1)[-1]]
        self.assertIn("protected_admin", local_model["properties"])
        oidc_response = next(item for item in session_schema["oneOf"]
            if "oidc" in item["x-uvm-auth-modes"])
        self.assertEqual(oidc_response.get("$ref"), None)
        deployment_schema = paths["/api/v1/deployment"]["get"]["responses"]["200"][
            "content"]["application/json"]["schema"]
        self.assertIn("connector_registry_revision", schema["components"]["schemas"][
            deployment_schema["$ref"].rsplit("/", 1)[-1]]["properties"])

    def test_registration_and_abandonment_export_strict_runtime_envelopes(self):
        paths = MODULE.export_schema()["paths"]
        command_schema = paths["/api/v1/assessment/commands"]["post"]["requestBody"][
            "content"]["application/json"]["schema"]
        registration, legacy = command_schema["oneOf"]
        self.assertFalse(registration["additionalProperties"])
        self.assertEqual(registration["properties"]["target_id"]["const"],
            "00000000-0000-0000-0000-000000000000")
        self.assertEqual(set(registration["required"]), set(registration["properties"]))
        self.assertTrue(legacy["additionalProperties"])
        abandon_schema = paths["/api/v1/assessment/commands/{command_id}/abandon"]["post"][
            "requestBody"]["content"]["application/json"]["schema"]
        self.assertFalse(abandon_schema["additionalProperties"])
        self.assertFalse(abandon_schema["properties"]["command"]["additionalProperties"])


if __name__ == "__main__":
    unittest.main()
