"""Real PostgreSQL journey for durable local account claim and lifecycle."""
from __future__ import annotations

import json
import io
import logging
import os
import secrets
import stat
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

import sqlalchemy as sa
from fastapi.testclient import TestClient


class LocalAccountsPostgreSQLTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dsn = os.environ.get("UVM_LOCAL_AUTH_TEST_DSN", "")
        if not cls.dsn:
            raise unittest.SkipTest("UVM_LOCAL_AUTH_TEST_DSN must point to a dedicated local-auth test database")
        cls.engine = sa.create_engine(cls.dsn, pool_pre_ping=True)
        with cls.engine.connect() as c:
            if c.dialect.name != "postgresql":
                raise RuntimeError("local account acceptance requires PostgreSQL")
            name = c.exec_driver_sql("select current_database()").scalar_one()
            major = int(c.exec_driver_sql("show server_version_num").scalar_one()) // 10000
            if name != "volt_easy_auth_test" or major != 18:
                raise RuntimeError("test DSN must name the owned volt_easy_auth_test PostgreSQL 18 database")
        from alembic import command
        from alembic.config import Config
        command.upgrade(Config("alembic.ini"), "head")

    @classmethod
    def tearDownClass(cls):
        if hasattr(cls, "engine"):
            cls.engine.dispose()

    def setUp(self):
        # This test database is unique to this outcome. Reset only its public
        # schema so each invocation exercises the committed migration chain.
        with self.engine.begin() as c:
            c.exec_driver_sql("DROP SCHEMA public CASCADE")
            c.exec_driver_sql("CREATE SCHEMA public")
        from alembic import command
        from alembic.config import Config
        command.upgrade(Config("alembic.ini"), "head")
        self.temp = tempfile.TemporaryDirectory(prefix="volt-easy-auth-")
        root = Path(self.temp.name)
        self.config_path = root / "local-auth.json"
        self.delivery_path = root / "bootstrap.json"
        self.key_path = root / "connector.key"
        self.key_path.write_bytes(secrets.token_bytes(32)); self.key_path.chmod(0o600)
        self.installation_id = "6c4be03e-8b9e-42a4-9545-7b17dd24a001"
        self.secret_source_id = "6c4be03e-8b9e-42a4-9545-7b17dd24a002"
        config = {"schema_version": 1, "installation_id": self.installation_id,
            "public_origin": "http://127.0.0.1",
            "secret_source": {"kind": "encrypted_local_v1", "secret_source_id": self.secret_source_id,
                "key_path": str(self.key_path)},
            "bootstrap_delivery": {"kind": "private_file", "path": str(self.delivery_path)},
            "session_policy": {"ttl_seconds": 3600},
            "trusted_ingress": {"mode": "loopback", "allowed_hosts": ["127.0.0.1"],
                "allowed_peer_cidrs": ["127.0.0.0/8"]}}
        self.config_path.write_text(json.dumps(config)); self.config_path.chmod(0o600)
        self.env = patch.dict(os.environ, {"UVM_AUTH_MODE": "local",
            "UVM_LOCAL_AUTH_CONFIG_FILE": str(self.config_path), "UVM_DB_URL": self.dsn,
            "UVM_API_CURSOR_SECRET": secrets.token_urlsafe(32),
            "UVM_INGRESS_ALLOWED_PEER_CIDRS": "127.0.0.0/8",
            "UVM_INGRESS_ALLOWED_HOSTS": "127.0.0.1"}, clear=False)
        self.env.start()
        from uvm.auth.maintenance import run as maintain
        maintain("prepare-setup", config_path=str(self.config_path))
        capability_doc = json.loads(self.delivery_path.read_text())
        self.assertEqual(stat.S_IMODE(self.delivery_path.stat().st_mode), 0o600)
        self.capability = capability_doc["capability"]
        from uvm.api.app import create_app
        self.app = create_app(self.engine, principals={}, cursor_secret=secrets.token_bytes(32))
        self.client = TestClient(self.app, base_url="http://127.0.0.1",
            client=("127.0.0.1", 52123))
        self.origin = {"Origin": "http://127.0.0.1", "Content-Type": "application/json"}

    def tearDown(self):
        self.env.stop()
        self.temp.cleanup()

    def _local_admin(self):
        password = secrets.token_urlsafe(20) + "A7!"
        claim = self.client.post("/api/v1/auth/setup/claim",
            json={"capability": self.capability, "username": "first-admin",
                "display_name": "First Admin", "password": password}, headers=self.origin)
        self.assertEqual(claim.status_code, 201, claim.text)
        cookie = self.client.cookies.get("uvm_session")
        return cookie, claim.json()["csrf_token"]

    def _registration_command(self, command_id, deployment, suffix="one"):
        return {"schema_version": 1, "command_id": command_id,
            "action": "connector.binding.register", "target_id": "00000000-0000-0000-0000-000000000000",
            "membership_ids": [],
            "expected_policy_revision": deployment["policy_revision"],
            "expected_authority_revision": deployment["authority_revision"],
            "expected_connector_registry_revision": deployment["connector_registry_revision"],
            "payload": {"display_name": "Test Scanner " + suffix, "source_family": "qualys",
                "source_account_id": "tenant-" + suffix, "scope_key": "prod",
                "environment_label": "Production", "rationale": "Register a disabled source binding",
                "evidence_ref": "test:registration:" + suffix, "grant_initial_read": True}}

    def _protected_client(self, cookie):
        client = TestClient(self.app, base_url="http://127.0.0.1", client=("127.0.0.1", 52125))
        client.cookies.set("uvm_session", cookie, domain="127.0.0.1", path="/")
        return client

    def test_claim_atomic_replay_session_restart_password_and_purpose_bound_enrolment(self):
        setup_password = secrets.token_urlsafe(20) + "A7!"
        payload = {"capability": self.capability, "username": "first-admin",
            "display_name": "First Admin", "password": setup_password}

        # The same token may be presented concurrently, but one transaction
        # commits the principal, authority, session and audit receipt only.
        def claim_once():
            with TestClient(self.app, base_url="http://127.0.0.1", client=("127.0.0.1", 52124)) as client:
                return client.post("/api/v1/auth/setup/claim", json=payload, headers=self.origin).status_code
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: claim_once(), range(2)))
        self.assertEqual(sorted(results), [201, 401])
        # The winning cookie belonged to its isolated concurrent client. Sign
        # in normally to verify independently persisted session issuance.
        signed_in = self.client.post("/api/v1/auth/local/login",
            json={"username": "first-admin", "password": setup_password}, headers=self.origin)
        self.assertEqual(signed_in.status_code, 200, signed_in.text)
        with self.engine.connect() as c:
            claim_receipt = c.execute(sa.text("select intent_id from assessment_command_receipts where action='local.setup.claimed'")).scalar_one()
            self.assertIsNotNone(claim_receipt)
            self.assertEqual(c.execute(sa.text("select count(*) from administration_reconciliation_intents where intent_id=:id"),
                {"id": claim_receipt}).scalar_one(), 1)
        response = self.client.get("/api/v1/auth/session")
        self.assertEqual(response.status_code, 200)
        session = response.json()
        self.assertEqual(session["credential_mode"], "local_session")
        self.assertTrue(session["protected_admin"])
        self.assertEqual(self.client.get("/api/v1/auth/config").json()["setup_state"], "claimed")
        self.assertEqual(self.client.post("/api/v1/auth/setup/claim", json=payload, headers=self.origin).status_code, 401)
        deployment = self.client.get("/api/v1/deployment")
        self.assertEqual(deployment.status_code, 200, deployment.text)
        self.assertTrue(deployment.json()["can_register_connector"])
        self.assertEqual(deployment.json()["connectors"], [])

        # The PostgreSQL row, not an in-process auth cache, restores authority.
        from uvm.api.app import create_app
        restart_app = create_app(self.engine, principals={}, cursor_secret=secrets.token_bytes(32))
        restarted = TestClient(restart_app, base_url="http://127.0.0.1", client=("127.0.0.1", 52125))
        restarted.cookies.update(self.client.cookies)
        self.assertEqual(restarted.get("/api/v1/auth/session").status_code, 200)
        csrf = restarted.get("/api/v1/auth/session").json()["csrf_token"]
        changed_password = secrets.token_urlsafe(20) + "C8!"
        wrong_csrf = restarted.post("/api/v1/auth/local/password",
            json={"current_password": setup_password, "new_password": changed_password}, headers=self.origin)
        self.assertEqual(wrong_csrf.status_code, 403)
        wrong_csrf = restarted.post("/api/v1/auth/local/password",
            json={"current_password": setup_password, "new_password": changed_password},
            headers={**self.origin, "X-CSRF-Token": secrets.token_urlsafe(32)})
        self.assertEqual(wrong_csrf.status_code, 403)
        other_session = TestClient(restart_app, base_url="http://127.0.0.1", client=("127.0.0.1", 52126))
        other_login = other_session.post("/api/v1/auth/local/login",
            json={"username": "first-admin", "password": setup_password}, headers=self.origin)
        self.assertEqual(other_login.status_code, 200)
        cross_session = restarted.post("/api/v1/auth/local/password",
            json={"current_password": setup_password, "new_password": changed_password},
            headers={**self.origin, "X-CSRF-Token": other_login.json()["csrf_token"]})
        self.assertEqual(cross_session.status_code, 403)
        changed = restarted.post("/api/v1/auth/local/password",
            json={"current_password": setup_password, "new_password": changed_password},
            headers={**self.origin, "X-CSRF-Token": csrf})
        self.assertEqual(changed.status_code, 204, changed.text)
        self.assertEqual(restarted.get("/api/v1/auth/session").status_code, 401)
        login = restarted.post("/api/v1/auth/local/login",
            json={"username": "first-admin", "password": changed_password}, headers=self.origin)
        self.assertEqual(login.status_code, 200, login.text)

        # Host account creation has no verifier or grants. Enrolment capability
        # purpose and account binding are checked before setting its password.
        from uvm.auth.maintenance import run as maintain
        maintain("create-account", "scanner-operator", "Scanner Operator", str(self.config_path))
        enrol_cap = json.loads(self.delivery_path.read_text())["capability"]
        with self.engine.connect() as c:
            row = c.execute(sa.text("select status, verifier, capability_generation from local_accounts where username_normalized='scanner-operator'")).one()
            self.assertEqual((row.status, row.verifier), ("pending", None))
        # Recovery cannot consume an enrolment capability.
        rejected = restarted.post("/api/v1/auth/local/recovery",
            json={"capability": enrol_cap, "new_password": secrets.token_urlsafe(20) + "D9!"}, headers=self.origin)
        self.assertEqual(rejected.status_code, 401)
        enrolled_password = secrets.token_urlsafe(20) + "E2!"
        enrolled = restarted.post("/api/v1/auth/local/enrol",
            json={"capability": enrol_cap, "new_password": enrolled_password}, headers=self.origin)
        self.assertEqual(enrolled.status_code, 204, enrolled.text)
        sign_in = restarted.post("/api/v1/auth/local/login",
            json={"username": "scanner-operator", "password": enrolled_password}, headers=self.origin)
        self.assertEqual(sign_in.status_code, 200, sign_in.text)
        self.assertFalse(sign_in.json()["protected_admin"])

    def test_abandonment_is_durable_and_fences_delayed_registration_retry(self):
        cookie, csrf = self._local_admin()
        deployment = self.client.get("/api/v1/deployment").json()
        command = self._registration_command(str(__import__("uuid").uuid4()), deployment)
        headers = {**self.origin, "X-CSRF-Token": csrf}
        abandoned = self.client.post(f"/api/v1/assessment/commands/{command['command_id']}/abandon",
            json={"schema_version": 1, "command": command, "rationale": "Request outcome was uncertain",
                "evidence_ref": "test:unknown-outcome"}, headers=headers)
        self.assertEqual(abandoned.status_code, 200, abandoned.text)
        self.assertEqual(abandoned.json()["disposition"], "not_committed")
        self.assertEqual(abandoned.json()["actor_id"], self.client.get("/api/v1/auth/session").json()["principal_id"])
        retry = self.client.post("/api/v1/assessment/commands", json=command, headers=headers)
        self.assertEqual(retry.status_code, 409, retry.text)
        self.assertEqual(retry.json()["error"]["code"], "command_terminal")
        again = self.client.post(f"/api/v1/assessment/commands/{command['command_id']}/abandon",
            json={"schema_version": 1, "command": command, "rationale": "Request outcome was uncertain",
                "evidence_ref": "test:unknown-outcome"}, headers=headers)
        self.assertEqual(again.status_code, 200)
        self.assertEqual(again.json()["audit_event_id"], abandoned.json()["audit_event_id"])
        changed = dict(command, payload={**command["payload"], "scope_key": "different"})
        conflict = self.client.post(f"/api/v1/assessment/commands/{command['command_id']}/abandon",
            json={"schema_version": 1, "command": changed, "rationale": "Changed bytes",
                "evidence_ref": "test:changed"}, headers=headers)
        self.assertEqual(conflict.status_code, 409)
        self.assertEqual(self.client.get("/api/v1/deployment").json()["connectors"], [])

    def test_registration_submission_races_abandonment_under_policy_serialization(self):
        cookie, csrf = self._local_admin()
        deployment = self.client.get("/api/v1/deployment").json()
        command = self._registration_command(str(__import__("uuid").uuid4()), deployment, "race")
        headers = {**self.origin, "X-CSRF-Token": csrf}
        disposition = {"schema_version": 1, "command": command,
            "rationale": "Resolve an uncertain registration", "evidence_ref": "test:race"}

        def submit():
            with self._protected_client(cookie) as client:
                return client.post("/api/v1/assessment/commands", json=command, headers=headers)

        def abandon():
            with self._protected_client(cookie) as client:
                return client.post(f"/api/v1/assessment/commands/{command['command_id']}/abandon",
                    json=disposition, headers=headers)

        with ThreadPoolExecutor(max_workers=2) as pool:
            submitted, abandoned = list(pool.map(lambda fn: fn(), (submit, abandon)))
        print("PG_COMMAND_RACE", {"command_id": command["command_id"],
            "submit_status": submitted.status_code, "abandon_status": abandoned.status_code,
            "disposition": abandoned.json().get("disposition"),
            "registered_count": len(self.client.get("/api/v1/deployment").json()["connectors"])})
        self.assertIn((submitted.status_code, abandoned.status_code), {(200, 200), (409, 200)})
        outcome = abandoned.json()["disposition"]
        self.assertIn(outcome, {"committed", "not_committed"})
        connectors = self.client.get("/api/v1/deployment").json()["connectors"]
        if outcome == "committed":
            self.assertEqual(submitted.status_code, 200)
            self.assertEqual(abandoned.json()["receipt"]["command_id"], command["command_id"])
            self.assertEqual(len(connectors), 1)
            self.assertEqual(connectors[0]["source"]["source_account_id"], "tenant-race")
        else:
            self.assertEqual(submitted.status_code, 409)
            self.assertEqual(submitted.json()["error"]["code"], "command_terminal")
            self.assertEqual(connectors, [])

    def test_abandonment_returns_exact_committed_receipt(self):
        _, csrf = self._local_admin()
        deployment = self.client.get("/api/v1/deployment").json()
        command = self._registration_command(str(__import__("uuid").uuid4()), deployment, "committed")
        headers = {**self.origin, "X-CSRF-Token": csrf}
        submitted = self.client.post("/api/v1/assessment/commands", json=command, headers=headers)
        self.assertEqual(submitted.status_code, 200, submitted.text)
        self.assertEqual(submitted.json()["target_id"], "00000000-0000-0000-0000-000000000000")
        self.assertIn("connector_id", submitted.json()["result"]["allocated_ids"])
        abandoned = self.client.post(f"/api/v1/assessment/commands/{command['command_id']}/abandon",
            json={"schema_version": 1, "command": command, "rationale": "Reconcile confirmed write",
                "evidence_ref": "test:committed"}, headers=headers)
        self.assertEqual(abandoned.status_code, 200, abandoned.text)
        self.assertEqual(abandoned.json()["disposition"], "committed")
        self.assertEqual(abandoned.json()["receipt"], submitted.json())

    def test_registration_and_abandonment_reject_schema_extras_at_runtime(self):
        _, csrf = self._local_admin()
        deployment = self.client.get("/api/v1/deployment").json()
        command = self._registration_command(str(__import__("uuid").uuid4()), deployment, "strict")
        command["unexpected"] = "rejected"
        headers = {**self.origin, "X-CSRF-Token": csrf}
        rejected = self.client.post("/api/v1/assessment/commands", json=command, headers=headers)
        self.assertEqual(rejected.status_code, 400, rejected.text)
        command.pop("unexpected")
        abandon = {"schema_version": 1, "command": command, "rationale": "uncertain",
            "evidence_ref": "test:strict", "unexpected": True}
        rejected_abandon = self.client.post(
            f"/api/v1/assessment/commands/{command['command_id']}/abandon",
            json=abandon, headers=headers)
        self.assertEqual(rejected_abandon.status_code, 422, rejected_abandon.text)

    def test_native_v2_typed_delegation_uses_independent_exact_ceilings(self):
        from uvm.assessment.api import _envelope_allows
        pair = {"connector_id": "11111111-1111-4111-8111-111111111111",
            "source_family": "qualys", "source_account_id": "tenant", "scope_key": "prod"}
        source = {key: pair[key] for key in ("source_family", "source_account_id", "scope_key")}
        limits = {"allowed_environments": [], "allowed_service_ids": [],
            "allowed_sla_clock_bases": [], "allowed_sla_severities": [],
            "allowed_sla_start_sources": [], "allowed_identity_scalar_fields": {}}
        duties = {"approval_requires_distinct_actor": True, "prohibit_requester_approval": True,
            "required_approver_count": 1, "prohibited_action_pairs": []}
        envelope = {"version": 2, "actions": ["connector.configure", "assessment.read"],
            "target_scope": {"kind": "deployment", "deployment_ids": [self.installation_id]},
            "connector_ids": [pair["connector_id"]], "connector_sources": [pair],
            "source_read_targets": [source], "limits": limits, "separation_of_duties": duties}
        connector_role = {"actions": ["connector.configure"], "target_scope": {
            "kind": "connector", "connector_ids": [pair["connector_id"]], "source_pairs": [pair]},
            "limits": limits, "separation_of_duties": duties}
        read_role = {"actions": ["assessment.read"], "target_scope": {
            "kind": "source_read", "membership_mode": "all_current", "source_scopes": [source]},
            "limits": limits, "separation_of_duties": duties}
        self.assertTrue(_envelope_allows(envelope, connector_role))
        self.assertTrue(_envelope_allows(envelope, read_role))
        invalid_pair = {**pair, "scope_key": "other"}
        self.assertFalse(_envelope_allows(envelope, {"actions": ["connector.configure"],
            "target_scope": {"kind": "connector", "connector_ids": [pair["connector_id"]],
                "source_pairs": [invalid_pair]}, "limits": limits, "separation_of_duties": duties}))
        self.assertFalse(_envelope_allows(envelope, {"actions": ["connector.configure"],
            "target_scope": {"kind": "source_read", "membership_mode": "all_current",
                "source_scopes": [source]}, "limits": limits, "separation_of_duties": duties}))

    def test_local_source_ceiling_stays_paired_to_its_granting_group(self):
        from datetime import datetime, timezone
        from uvm.auth.schema import AuthorityContext
        source_a = ("qualys", "account-a", "prod")
        source_b = ("qualys", "account-b", "prod")
        context = AuthorityContext(principal_id="principal", credential_mode="local_session",
            issuer=None, subject=None, link_id=None, link_revision=None, session_id="session",
            session_revision=1, access_groups=("read-a", "connector-b"), group_revision=1,
            mapping_revision=1, policy_revision=1, source_scopes=(source_a, source_b), role_ids=(),
            evaluated_at=datetime.now(timezone.utc), group_roles=(
                ("read-a", ("assessment.read",)), ("connector-b", ("connector.configure",))),
            group_scopes=(("read-a", (source_a,)), ("connector-b", (source_b,))))
        self.assertEqual(context.scopes_for_granting_groups({"read-a"}), {source_a})
        self.assertEqual(context.scopes_for_granting_groups({"connector-b"}), {source_b})



    def test_audit_failure_rolls_back_claim_and_leaves_capability_reusable(self):
        setup_password = secrets.token_urlsafe(20) + "F3!"
        payload = {"capability": self.capability, "username": "rollback-admin",
            "display_name": "Rollback Admin", "password": setup_password}
        with self.engine.begin() as c:
            c.exec_driver_sql("""CREATE FUNCTION reject_local_claim_audit() RETURNS trigger LANGUAGE plpgsql AS $$
                BEGIN IF NEW.action = 'local.setup.claimed' THEN RAISE EXCEPTION 'injected local audit failure'; END IF; RETURN NEW; END $$""")
            c.exec_driver_sql("CREATE TRIGGER reject_local_claim_audit BEFORE INSERT ON assessment_audit_events FOR EACH ROW EXECUTE FUNCTION reject_local_claim_audit()")
        failed = self.client.post("/api/v1/auth/setup/claim", json=payload, headers=self.origin)
        self.assertEqual(failed.status_code, 503)
        with self.engine.connect() as c:
            self.assertEqual(c.exec_driver_sql("select count(*) from local_accounts").scalar_one(), 0)
            self.assertEqual(c.exec_driver_sql("select count(*) from assessment_command_receipts where action='local.setup.claimed'").scalar_one(), 0)
            self.assertEqual(c.exec_driver_sql("select count(*) from administration_reconciliation_intents").scalar_one(), 0)
            self.assertIsNone(c.exec_driver_sql("select claimed_at from local_auth_installation where singleton_id=1").scalar_one())
            self.assertIsNone(c.exec_driver_sql("select consumed_at from local_auth_capabilities where purpose='setup'").scalar_one())
        with self.engine.begin() as c:
            c.exec_driver_sql("DROP TRIGGER reject_local_claim_audit ON assessment_audit_events")
            c.exec_driver_sql("DROP FUNCTION reject_local_claim_audit()")
        claimed = self.client.post("/api/v1/auth/setup/claim", json=payload, headers=self.origin)
        self.assertEqual(claimed.status_code, 201, claimed.text)

    def test_database_failure_logs_hide_password_verifier_and_capability(self):
        password = "Secret Database Failure Password 8!"
        with self.engine.begin() as c:
            c.exec_driver_sql("""CREATE FUNCTION reject_local_account_write() RETURNS trigger LANGUAGE plpgsql AS $$
                BEGIN RAISE EXCEPTION 'injected account write failure'; END $$""")
            c.exec_driver_sql("CREATE TRIGGER reject_local_account_write BEFORE INSERT ON local_accounts FOR EACH ROW EXECUTE FUNCTION reject_local_account_write()")
        logger = logging.getLogger("uvm.api.app")
        sink = io.StringIO(); handler = logging.StreamHandler(sink); logger.addHandler(handler)
        try:
            response = self.client.post("/api/v1/auth/setup/claim", json={"capability": self.capability,
                "username": "first-admin", "display_name": "First Admin", "password": password}, headers=self.origin)
        finally:
            logger.removeHandler(handler)
            with self.engine.begin() as c:
                c.exec_driver_sql("DROP TRIGGER reject_local_account_write ON local_accounts")
                c.exec_driver_sql("DROP FUNCTION reject_local_account_write()")
        self.assertEqual(response.status_code, 503)
        self.assertNotIn(password, sink.getvalue())
        self.assertNotIn("$argon2id$", sink.getvalue())
        self.assertNotIn(self.capability, sink.getvalue())

    def test_failed_login_attempt_is_durably_throttled(self):
        self._local_admin()
        response = self.client.post("/api/v1/auth/local/login",
            json={"username": "first-admin", "password": "wrong password"}, headers=self.origin)
        self.assertEqual(response.status_code, 401)
        with self.engine.connect() as c:
            attempts = c.execute(sa.text("select coalesce(sum(attempts), 0) from local_login_throttles")).scalar_one()
        self.assertGreaterEqual(attempts, 1, "failed attempt counter must commit before returning 401")

    def test_password_contract_uses_normalized_phc_and_exact_account_names(self):
        from uvm.auth.local import LocalAuth, _password_hash, _password_verify
        composed = "Cafe\u0301PasswordLong!7"
        verifier = _password_hash(composed)
        self.assertTrue(verifier.startswith("$argon2id$v=19$m=19456,t=2,p=1$"))
        self.assertTrue(_password_verify(verifier, "Caf\u00e9PasswordLong!7"))
        self.assertFalse(_password_verify(verifier, composed + "x"))
        with self.assertRaises(Exception):
            LocalAuth._validate_password("short")
        with self.assertRaises(Exception):
            LocalAuth._validate_password("passwordpassword")
        with self.assertRaises(Exception):
            self.app.state.oidc_auth._validate_account(" first-admin", "Name", "A valid password long 1!")

    def test_local_config_rejects_remote_http_unsupported_scheme_and_host_mismatch(self):
        from uvm.auth.local import load_local_config
        original = json.loads(self.config_path.read_text())
        with patch.dict(os.environ, {"UVM_LOCAL_AUTH_CONFIG_FILE": str(self.config_path)}):
            for origin in ("http://10.1.2.3", "ftp://127.0.0.1"):
                invalid = dict(original, public_origin=origin)
                self.config_path.write_text(json.dumps(invalid))
                self.config_path.chmod(0o600)
                with self.subTest(origin=origin), self.assertRaises(RuntimeError):
                    load_local_config()
            invalid = json.loads(json.dumps(original))
            invalid["trusted_ingress"]["allowed_hosts"] = ["example.invalid"]
            self.config_path.write_text(json.dumps(invalid))
            self.config_path.chmod(0o600)
            with self.assertRaises(RuntimeError):
                load_local_config()

    def test_password_recovery_race_never_leaves_old_password_session_valid(self):
        old_password = "Initial Admin Password 6!"
        claim = self.client.post("/api/v1/auth/setup/claim", json={"capability": self.capability,
            "username": "first-admin", "display_name": "First Admin", "password": old_password},
            headers=self.origin)
        self.assertEqual(claim.status_code, 201, claim.text)
        from uvm.auth.maintenance import run as maintain
        maintain("issue-recovery", "first-admin", config_path=str(self.config_path))
        recovery_capability = json.loads(self.delivery_path.read_text())["capability"]
        new_password = "A New Password Long Enough 7!"
        barrier = threading.Barrier(2)
        login_client = TestClient(self.app, base_url="http://127.0.0.1", client=("127.0.0.1", 52131))
        recovery_client = TestClient(self.app, base_url="http://127.0.0.1", client=("127.0.0.1", 52132))
        def login():
            barrier.wait()
            return login_client.post("/api/v1/auth/local/login",
                json={"username": "first-admin", "password": old_password}, headers=self.origin)
        def recover():
            barrier.wait()
            return recovery_client.post("/api/v1/auth/local/recovery",
                json={"capability": recovery_capability, "new_password": new_password}, headers=self.origin)
        with ThreadPoolExecutor(max_workers=2) as pool:
            login_result, recovery_result = list(pool.map(lambda fn: fn(), (login, recover)))
        self.assertEqual(recovery_result.status_code, 204, recovery_result.text)
        self.assertIn(login_result.status_code, {200, 401})
        if login_result.status_code == 200:
            login_client.cookies.set("uvm_session", login_result.cookies.get("uvm_session"),
                domain="127.0.0.1", path="/")
            self.assertEqual(login_client.get("/api/v1/auth/session").status_code, 401,
                "a session issued before recovery must be revoked by the credential revision change")

    def test_password_change_race_never_leaves_old_password_session_valid(self):
        old_password = "Initial Admin Password 6!"
        claim = self.client.post("/api/v1/auth/setup/claim", json={"capability": self.capability,
            "username": "first-admin", "display_name": "First Admin", "password": old_password},
            headers=self.origin)
        self.assertEqual(claim.status_code, 201, claim.text)
        csrf = claim.json()["csrf_token"]
        new_password = "Changed Admin Password Long 8!"
        barrier = threading.Barrier(2)
        login_client = TestClient(self.app, base_url="http://127.0.0.1", client=("127.0.0.1", 52141))
        def login():
            barrier.wait()
            return login_client.post("/api/v1/auth/local/login",
                json={"username": "first-admin", "password": old_password}, headers=self.origin)
        def change():
            barrier.wait()
            return self.client.post("/api/v1/auth/local/password",
                json={"current_password": old_password, "new_password": new_password},
                headers={**self.origin, "X-CSRF-Token": csrf})
        with ThreadPoolExecutor(max_workers=2) as pool:
            login_result, change_result = list(pool.map(lambda fn: fn(), (login, change)))
        self.assertEqual(change_result.status_code, 204, change_result.text)
        self.assertIn(login_result.status_code, {200, 401})
        if login_result.status_code == 200:
            login_client.cookies.update(login_result.cookies)
            self.assertEqual(login_client.get("/api/v1/auth/session").status_code, 401)
        self.assertEqual(self.client.post("/api/v1/auth/local/login",
            json={"username": "first-admin", "password": new_password}, headers=self.origin).status_code, 200)

    def test_local_mode_never_falls_back_when_database_records_local_install(self):
        from types import SimpleNamespace
        from uvm.auth.service import install_auth
        app = SimpleNamespace(state=SimpleNamespace(engine=self.engine))
        for mode in ("bearer", "oidc", "unknown"):
            with patch.dict(os.environ, {"UVM_AUTH_MODE": mode}):
                with self.assertRaises(RuntimeError):
                    install_auth(app)
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("UVM_AUTH_MODE", None)
            with self.assertRaises(RuntimeError):
                install_auth(app)

    def test_non_admin_cannot_read_deployment_inventory(self):
        self._local_admin()
        from uvm.auth.maintenance import run as maintain
        maintain("create-account", "scanner-operator", "Scanner Operator", str(self.config_path))
        capability = json.loads(self.delivery_path.read_text())["capability"]
        operator = TestClient(self.app, base_url="http://127.0.0.1", client=("127.0.0.1", 52135))
        self.assertEqual(operator.post("/api/v1/auth/local/enrol",
            json={"capability": capability, "new_password": "Scanner Operator Password 7!"},
            headers=self.origin).status_code, 204)
        response = operator.post("/api/v1/auth/local/login",
            json={"username": "scanner-operator", "password": "Scanner Operator Password 7!"}, headers=self.origin)
        self.assertEqual(response.status_code, 200)
        inventory = operator.get("/api/v1/deployment")
        self.assertEqual(inventory.status_code, 403, inventory.text)

    def test_native_principal_disable_reenable_does_not_restore_old_local_session(self):
        _, csrf = self._local_admin()
        from uvm.auth.maintenance import run as maintain
        maintain("create-account", "scanner-operator", "Scanner Operator", str(self.config_path))
        capability = json.loads(self.delivery_path.read_text())["capability"]
        operator = TestClient(self.app, base_url="http://127.0.0.1", client=("127.0.0.1", 52136))
        password = "Scanner Operator Password 7!"
        self.assertEqual(operator.post("/api/v1/auth/local/enrol",
            json={"capability": capability, "new_password": password}, headers=self.origin).status_code, 204)
        login = operator.post("/api/v1/auth/local/login",
            json={"username": "scanner-operator", "password": password}, headers=self.origin)
        self.assertEqual(login.status_code, 200)
        operator.cookies.update(login.cookies)
        principal_id = login.json()["principal_id"]

        def update(enabled):
            deployment = self.client.get("/api/v1/deployment").json()
            policy_revision, authority_revision = deployment["policy_revision"], deployment["authority_revision"]
            command = {"command_id": str(__import__("uuid").uuid4()), "action": "principal.update",
                "target_id": "00000000-0000-4000-8000-000000000000", "membership_ids": [],
                "expected_revisions": {"target": policy_revision, "policy": policy_revision,
                    "identity_membership": 0, "owners": 0, "authority": authority_revision},
                "payload": {"principal_id": principal_id, "enabled": enabled}}
            response = self.client.post("/api/v1/assessment/commands", json=command,
                headers={**self.origin, "X-CSRF-Token": csrf})
            self.assertEqual(response.status_code, 200, response.text)
        update(False)
        self.assertEqual(operator.get("/api/v1/auth/session").status_code, 401)
        update(True)
        self.assertEqual(operator.get("/api/v1/auth/session").status_code, 401)

    def test_prepare_setup_reemits_existing_capability_without_rotation(self):
        from uvm.auth.maintenance import run as maintain
        before = json.loads(self.delivery_path.read_text())["capability"]
        with self.engine.connect() as c:
            audit_count = c.exec_driver_sql("select count(*) from assessment_audit_events where action='local.setup.capability_issued'").scalar_one()
            cap_count = c.exec_driver_sql("select count(*) from local_auth_capabilities where purpose='setup' and consumed_at is null").scalar_one()
        maintain("prepare-setup", config_path=str(self.config_path))
        after = json.loads(self.delivery_path.read_text())["capability"]
        self.assertEqual(after, before)
        with self.engine.connect() as c:
            self.assertEqual(c.exec_driver_sql("select count(*) from assessment_audit_events where action='local.setup.capability_issued'").scalar_one(), audit_count)
            self.assertEqual(c.exec_driver_sql("select count(*) from local_auth_capabilities where purpose='setup' and consumed_at is null").scalar_one(), cap_count)

    def test_restore_capability_revocation_also_invalidates_local_sessions(self):
        self._local_admin()
        self.assertEqual(self.client.get("/api/v1/auth/session").status_code, 200)
        from uvm.auth.maintenance import run as maintain
        maintain("revoke-capabilities", config_path=str(self.config_path))
        self.assertEqual(self.client.get("/api/v1/auth/session").status_code, 401)

    def test_user_and_peer_buckets_are_independent_with_separate_limits(self):
        self._local_admin()
        def wrong(username):
            return self.client.post("/api/v1/auth/local/login",
                json={"username": username, "password": "wrong password"}, headers=self.origin).status_code
        self.assertEqual([wrong("first-admin") for _ in range(5)], [401] * 4 + [429])
        self.assertEqual(wrong("first-admin"), 429)
        # The user bucket is blocked, but another username on this peer still
        # reaches the independent peer counter and receives ordinary denial.
        self.assertEqual(wrong("missing-account"), 401)
        with self.engine.connect() as c:
            counts = list(c.execute(sa.text("select attempts, blocked_until from local_login_throttles order by attempts desc")))
        self.assertEqual(sorted(row.attempts for row in counts), [1, 5, 6])
        self.assertEqual(sum(row.blocked_until is not None for row in counts), 1)


if __name__ == "__main__":
    unittest.main()
